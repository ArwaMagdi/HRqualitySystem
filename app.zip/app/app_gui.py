from flask import Flask,jsonify,request,render_template
# from model import TextClassification
app = Flask(__name__)
# tc = TextClassification() ## get data,preprocess and train
###########################
@app.route("/", methods=('GET', 'POST'))
def home():
    return render_template('index.html')

# @app.route("/train")
# def train():
#     tc.model_train()
    
#     return render_template('result.html',message='model trained successfully')

# @app.route("/evaluate")
# def evaluate():
#     score = tc.model_evaluate()
#     return render_template('result.html',message = 'Your model score is '+str(score))

# @app.route("/predict_gui")
# def predict_gui():
#     return render_template('predict.html')
    
# @app.route("/predict")
# def predict():
#     text  = request.args['text']
#     label = tc.model_predict(text)
#     return render_template('result.html',message = 'Your data label is '+str(label),label=label)
###########################
app.run()